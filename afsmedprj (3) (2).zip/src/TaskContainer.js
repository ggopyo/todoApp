import React, { useCallback, useEffect, useState } from "react";
import { Task } from "./Task";
import CustomDivider from "./CustomDivider";
import update from "immutability-helper";
import { Divider, Typography } from "@mui/material";
import { afs } from "./afs";

const TaskContainer = (props) => {
  const {
    tasks,
    rootWidth,
    setTasks,
    handleToggle,
    handleDelete,
    checkboxToggle,
  } = props;
  const [doneTasks, setDoneTasks] = useState([]);
  const [undoneTasks, setUnDoneTasks] = useState([]);
  const taskProps = (task, index, direction) => {
    return {
      index,
      id: task.id,
      task,
      tasks,
      title: task.title,
      done: task.done,
      check: task.check,
      moveCard1,
      moveCard2,
      rootWidth,
      setTasks,
      handleDelete,
      checkboxToggle,
      handleToggle,
      direction,
    };
  };

  const moveCard1 = (dragIndex, hoverIndex) => {
    setTasks((prevCards) => {
      return update(prevCards, {
        $splice: [
          [dragIndex, 1],
          [hoverIndex, 0, prevCards[dragIndex]],
        ],
      });
    });
  };

  const moveCard2 = (dragIndex, hoverIndex) => {
    setTasks((prevCards) => {
      return update(prevCards, {
        $splice: [
          [dragIndex, 1],
          [hoverIndex, 0, prevCards[dragIndex]],
        ],
      });
    });
  };

  const renderCard1 = (task, index, direction) => {
    return <Task {...taskProps(task, index, direction)} />;
  };
  const renderCard2 = (task, index) => {
    return <Task {...taskProps(task, index)} />;
  };

  useEffect(() => {
    setDoneTasks(tasks.filter((item) => item.done));
    setUnDoneTasks(tasks.filter((item) => !item.done));
    afs(doneTasks);
    afs(undoneTasks);
  }, [tasks]);

  return (
    <>
      {" "}
      <CustomDivider
        rootWidth={rootWidth}
        text="완&nbsp;&nbsp;&nbsp;&nbsp;료"
      />
      <div style={{ width: 500 }}>
        {tasks
          .filter((item) => item.done)
          .map((task, index) => {
            return renderCard1(task, index, "up");
          })}
      </div>{" "}
      <CustomDivider rootWidth={rootWidth} text="미완료" />
      <div style={{ width: 500 }}>
        {tasks
          .filter((item) => !item.done)
          .map((task, index) => {
            return renderCard2(task, index, "down");
          })}
      </div>
    </>
  );
};

export default TaskContainer;
