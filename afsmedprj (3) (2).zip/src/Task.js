import { ListItem, ListItemText } from "@mui/material";
import { Box } from "@mui/system";
import { useRef } from "react";
import { useDrag, useDrop } from "react-dnd";
import ActionButtons from "./ActionButtons";
import { afs } from "./afs";
import CustomDivider from "./CustomDivider";
import { ItemTypes } from "./ItemTypes";
import { numberingStyle } from "./styles";
const style = {
  border: "0.1px dashed gray",
  padding: "0.5rem 1rem",
  marginBottom: ".5rem",
  backgroundColor: "white",
  cursor: "move",
};

const noneTextStyle = {
  "& .MuiTypography-root": {
    userSelect: "none",
  },
  mt: 1,
  ml: 1,
};
export const Task = ({
  index,
  realIndex,
  id,
  title,
  done,
  check,
  moveCard1,
  moveCard2,
  rootWidth,
  task,
  tasks,
  setTasks,
  handleToggle,
  checkboxToggle,
  handleDelete,
  ifDone,
  direction,
}) => {
  const ref = useRef(null);
  const [{ handlerId }, drop] = useDrop({
    accept: ItemTypes.CARD,
    collect(monitor) {
      return {
        handlerId: monitor.getHandlerId(),
      };
    },
    hover(item, monitor) {
      if (!ref.current) {
        return;
      }
      const dragIndex = item.realIndex;
      const hoverIndex = realIndex;
      var a = [dragIndex, hoverIndex];

      // 드래그해서 그자리에 드랍할 경우
      if (dragIndex === hoverIndex) {
        return;
      }
      // 화면의 사각형을 지정한다
      const hoverBoundingRect = ref.current?.getBoundingClientRect();
      // 수직 축의 중간지점을 얻는다
      const hoverMiddleY =
        (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2;
      // 마우스 좌표를 얻는다
      const clientOffset = monitor.getClientOffset();
      // 화면 상단의 좌표를 얻는다
      const hoverClientY = clientOffset.y - hoverBoundingRect.top;
      // 마우스 좌표가 사각형 아이템의 중간 지점을 넘었을 때만 작동한다
      // 아래쪽으로 드래그할 때는, 오직 마우스 커서가 사각형의 50% 지점 아래에 있을 때만 움직인다
      // 위쪽으로 드래그할 때는, 오직 마우스 커서가 사각형의 50% 지점 위에 있을 때만 움직인다
      // 아래쪽으로 드래그
      if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
        return;
      }
      // 위쪽으로 드래그
      if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
        return;
      }
      // 실제로 옮기는 액션을 취하는 곳
      if (direction !== "up") moveCard1(dragIndex, hoverIndex);
      else moveCard2(dragIndex, hoverIndex);

      // Note: we're mutating the monitor item here!
      // Generally it's better to avoid mutations,
      // but it's good here for the sake of performance
      // to avoid expensive index searches.
      item.realIndex = hoverIndex;
    },
  });
  const [{ isDragging }, drag] = useDrag({
    type: ItemTypes.CARD,
    item: () => {
      return { id, realIndex };
    },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });
  const opacity = isDragging ? 0 : 1;
  drag(drop(ref));
  const actionButtonProps = {
    handleDelete,
    task,
    checkboxToggle,
    check,
    id,
    handleToggle,
    done,
  };

  return (
    <>
      <ListItem
        ref={ref}
        style={{ ...style, opacity }}
        data-handler-id={handlerId}
        sx={{
          display: "flex",
          justifyContent: "flex-end",
        }}
        secondaryAction={<ActionButtons {...actionButtonProps} />}
        disablePadding
      >
        <Box sx={numberingStyle} variant="rounded">
          {"" + (index + 1)}
        </Box>
        <ListItemText
          sx={noneTextStyle}
          primary={
            "index:" + index + " " + "realIndex:" + realIndex + " " + title
          }
        />
      </ListItem>{" "}
    </>
  );
};
