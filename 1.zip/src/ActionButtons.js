import Delete from "@mui/icons-material/Delete";
import {
  Box,
  Button,
  ButtonBase,
  Checkbox,
  FormControlLabel,
  Typography,
} from "@mui/material";
import React from "react";

const ActionButtons = ({
  handleDelete,
  task,
  checkboxToggle,
  check,
  id,
  handleToggle,
  done,
}) => {
  return (
    <Box sx={{ display: "flex", alignItems: "center" }}>
      <ButtonBase>
        <Delete
          edge="end"
          onClick={() => {
            handleDelete(task);
          }}
          sx={{ mr: 1 }}
        />
      </ButtonBase>
      <FormControlLabel
        sx={{ mr: 0 }}
        control={
          <Checkbox
            checked={check}
            onClick={() => checkboxToggle(id)}
            style={{
              color: "#16ABB9",
            }}
            value="cryon"
          />
        }
        label={
          <Typography variant="h6" style={{ color: "#2979ff" }}></Typography>
        }
      />
      <Button
        sx={{ color: "#16ABB9", width: 40, p: 0 }}
        onClick={() => handleToggle(id)}
        variant="outlined"
      >
        {done ? "완료" : "미완료"}
      </Button>
    </Box>
  );
};

export default ActionButtons;
