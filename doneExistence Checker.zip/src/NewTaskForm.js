import { Alert, Button, TextField } from "@mui/material";
import { Box } from "@mui/system";
import { useRef, useState } from "react";
import { afs } from "./afs";
import { alertStyle, boxStyle, buttonStyle, inputStyle } from "./styles";

const NewTaskForm = ({
  setTasks,
  rootWidth,
  setError,
  error,

  taskCreate,
}) => {
  const [title, setTitle] = useState("");
  const handleChange = (event) => {
    setError(false);
    setTitle(event.target.value);
  };
  const handleSubmit = () => {
    if ((title.match(/ /g) || []).length !== title.length) {
      taskCreate(title);
      setTitle("");
    } else {
      setError(true);
      setTitle("");
    }
  };

  const handlePressEnter = (event) => {
    if (event.keyCode === 13 && event.target.value) {
      event.preventDefault();
      if ((title.match(/ /g) || []).length !== title.length) {
        setTasks((prev) => [
          ...prev,
          {
            id: (prev.length + 1).toString(),
            title,
            done: false,
            check: false,
          },
        ]);
        setTitle("");
      } else {
        setError(true);
        setTitle("");
      }
    }
  };
  return (
    <>
      <Box sx={boxStyle(rootWidth)}>
        <TextField
          sx={inputStyle(rootWidth)}
          placeholder="새로울 할 일을 입력하세요."
          autoFocus
          variant="outlined"
          value={title}
          onKeyDown={handlePressEnter}
          onChange={handleChange}
          inputRef={(input) => input && input.focus()}
        ></TextField>

        <Button onClick={handleSubmit} sx={buttonStyle(rootWidth)}>
          등록하기
        </Button>
      </Box>{" "}
      <Alert sx={alertStyle(error, rootWidth)}>
        공백은 입력할 수 없습니다. 공백을 제거해 주세요.
      </Alert>
    </>
  );
};

export default NewTaskForm;
