import { useState, useCallback, useEffect, useRef } from "react";
import { Card, Task } from "./Task";
import update from "immutability-helper";
import NewTaskForm from "./NewTaskForm";
import { afs } from "./afs";
import Title from "./Title";
import { rootDivStyle } from "./styles";
import Statistic from "./Statistic";
import TaskContainer from "./TaskContainer";
const initialState = [
  {
    id: "1",
    title: "서비스 개발팀 회의 내용 정리",
    done: true,
    check: false,
  },
  { id: "2", title: "PR 템플릿 만들기", done: false, check: false },
  { id: "3", title: "React UI 라이브러리 검토", done: false, check: false },
];
export const Tasks = () => {
  const [tasks, setTasks] = useState(initialState);
  // const [dividingIndex, setDividingIndex] = useState(
  //   initialState.filter((item) => item.done).length
  // );

  const rootRef = useRef(null);
  const [error, setError] = useState(false);
  const [rootWidth, setRootWidth] = useState(null);
  const updateDimensions = () => {
    console.log(rootRef.current.clientWidth);
    if (rootRef.current) setRootWidth(rootRef.current.clientWidth);
  };

  const handleDelete = useCallback(
    (value) => {
      setTasks(
        tasks.filter((task) => {
          return task !== value;
        })
      );
    },
    [tasks]
  );
  const handleToggle = useCallback(
    (id) => {
      setTasks(
        tasks.map((task, index) => {
          // if (task.id === id)
          //   index >= dividingIndex
          //     ? setDividingIndex((prev) => prev + 1)
          //     : setDividingIndex((prev) => prev - 1);

          return task.id === id ? { ...task, done: !task.done } : task;
        })
      );
    },
    [tasks]
  );
  const checkboxToggle = useCallback(
    (id) => {
      setTasks(
        tasks.map((task) =>
          task.id === id ? { ...task, check: !task.check } : task
        )
      );
    },
    [tasks]
  );
  useEffect(() => {
    // afs(tasks);
    // afs(dividingIndex);
  }, [tasks]);
  const taskCreate = useCallback((title) => {
    setTasks((prev) => [
      ...prev,
      { id: (prev.length + 1).toString(), title, done: false, check: false },
    ]);
  }, []);

  useEffect(() => {
    window.addEventListener("resize", updateDimensions);
    setRootWidth(rootRef.current.clientWidth);
    afs(rootWidth);
    return () => {
      window.removeEventListener("resize", updateDimensions);
    };
  }, []);

  const statisticProps = { tasks, rootWidth, error };
  const newTaskFormProps = { setTasks, rootWidth, setError, error, taskCreate };
  const taskContainerProps = {
    tasks,
    rootWidth,
    setTasks,
    handleDelete,
    handleToggle,
    checkboxToggle,
    // dividingIndex,
  };
  return (
    <div ref={rootRef} style={rootDivStyle}>
      <Title rootWidth={rootWidth} />
      <NewTaskForm {...newTaskFormProps} />
      <Statistic {...statisticProps} />
      <TaskContainer {...taskContainerProps} />
    </div>
  );
};
