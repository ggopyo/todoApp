import React, { useCallback, useEffect, useState } from "react";
import { Task } from "./Task";
import CustomDivider from "./CustomDivider";
import update from "immutability-helper";
import { Divider, Typography } from "@mui/material";
import { afs } from "./afs";
import { position } from "stylis";

export const useMousePosition = () => {
  const [position, setPosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const setFromEvent = (e) => setPosition({ x: e.clientX, y: e.clientY });
    window.addEventListener("mousemove", setFromEvent);

    return () => {
      window.removeEventListener("mousemove", setFromEvent);
    };
  }, []);

  return position;
};

const TaskContainer = (props) => {
  const {
    tasks,
    rootWidth,
    setTasks,
    handleToggle,
    handleDelete,
    checkboxToggle,
  } = props;
  const [doneTasks, setDoneTasks] = useState({ flag: false, data: [] });
  const [undoneTasks, setUnDoneTasks] = useState({ flag: true, data: [] });
  const [doneTasksPredicate, setDoneTasksPredicate] = useState([]);
  const [undoneTasksPredicate, setUnDoneTasksPredicate] = useState([]);
  const [check, setCheck] = useState({
    ifDragging: false,
    hovering: [],
    pos: [0, 0],
  });

  const taskProps = (task, index, ifDone, realIndex) => {
    return {
      index,
      id: task.id,
      task,
      tasks,
      title: task.title,
      done: task.done,
      check: task.check,
      moveCard,
      rootWidth,
      setTasks,
      handleDelete,
      checkboxToggle,
      handleToggle,
      realIndex,
      ifDone,
    };
  };
  Array.prototype.containsAll = function () {
    return Array.from(arguments).every((i) => this.includes(i));
  };
  const moveCard = (dragIndex, hoverIndex) => {
    if (check.flag && hoverIndex <= setDoneTasks.length - 1)
      setCheck({
        flag: true,
        hovering: isNaN(check.hovering)
          ? { ...check.hovering }
          : { ...check.hovering, hoverIndex },
        pos: { ...position },
      });
    else
      setCheck({
        flag: false,
        hovering: isNaN(check.hovering)
          ? { ...check.hovering }
          : { ...check.hovering, hoverIndex },
        pos: { ...position },
      });
    afs(check);
    if (doneTasksPredicate.containsAll(check.hovering)) {
      setTasks((prevCards) => {
        return update(prevCards, {
          $splice: [
            [dragIndex, 1],
            [hoverIndex, 0, prevCards[dragIndex]],
          ],
        });
      });
    } else {
      setCheck({
        flag: false,
        hovering: [...check.hovering, hoverIndex],
        pos: { x: 0, y: 0 },
      });
      setTasks([...doneTasks.data, ...undoneTasks.data]);
    }
  };

  const renderCard = (task, index, ifDone, realIndex = index) => {
    return <Task {...taskProps(task, index, ifDone, realIndex)} />;
  };

  useEffect(() => {
    setDoneTasks({ ...doneTasks, data: tasks.filter((item) => item.done) });
    setUnDoneTasks({
      ...undoneTasks,
      data: tasks.filter((item) => !item.done),
    });

    setDoneTasksPredicate(
      tasks
        .map((item, index) => item.done && index)
        .filter((item) => typeof item === "number")
    );
    setUnDoneTasksPredicate(
      tasks
        .map((item, index) => !item.done && index)
        .filter((item) => typeof item === "number")
    );

    afs(doneTasksPredicate);
    afs(doneTasksPredicate);
  }, [tasks]);

  return (
    <div style={{ width: 500 }}>
      <CustomDivider
        rootWidth={rootWidth}
        text="완&nbsp;&nbsp;&nbsp;&nbsp;료"
      />
      {doneTasks.data.map((task, index) => {
        {
          /* afs("done-index" + " " + index + " " + index); */
        }
        return renderCard(task, index, true);
      })}
      <CustomDivider rootWidth={rootWidth} text="미완료" />
      {undoneTasks.data.map((task, index) => {
        {
          /* afs("undone-index" + " " + index + " " + (doneTasksLength + index)); */
        }
        return renderCard(task, index, false, doneTasks.length + index);
      })}
    </div>
  );
};

export default TaskContainer;
